AK MEDIA VAULT - FIXED
index.html: ছোট (2.5MB -> ~126KB) করা হয়েছে, splash আটকে থাকবে না।
সমস্যার আসল কারণ: সাধারণ HTML-to-APK builder-এ WebView ফাইল পিকার ও স্টোরেজ পারমিশন হ্যান্ডেল করে না।
সমাধান: ../AK_MEDIA_VAULT_ANDROID প্রজেক্ট (Native WebView) - এতে পারমিশন চায় ও ফাইল পিকার কাজ করে।
